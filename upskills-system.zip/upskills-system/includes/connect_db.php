<?php
$con = mysqli_connect('localhost','root','','upskills');
    if(!($con)){
        
        echo "something Wrong";
    }
// one of two command enough.
//mysqli_query($con, "SET NAMES 'utf8'"); 
//mysqli_query($con, "SET CHARACTER SET utf8"); 

?>
