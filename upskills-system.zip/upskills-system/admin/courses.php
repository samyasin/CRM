<?php include '../includes/header.php';?>
<?php include '../includes/connect_db.php';?>

<?php
if (isset($_POST['submit'])){
	$category_id       = $_POST['category_id'];
	$course_name       = $_POST['course_name'];
	$course_name_ar    = $_POST['course_name_ar'];
	$course_desc       = $_POST['course_desc'];
	$course_desc_ar    = $_POST['course_desc_ar'];
	$course_level      = $_POST['course_level'];
	$course_hours      = $_POST['course_hours'];
	$course_content    = $_POST['course_content'];
	$course_content_ar = $_POST['course_content_ar'];
	$course_price      = $_POST['course_price'];
	$course_spe_price  = $_POST['course_spe_price'];
	$start_date        = $_POST['start_date'];
	$end_date          = $_POST['end_date'];

	
	if($_FILES['course_image']['error'] == 0){
		$tmp_name = $_FILES['course_image']['tmp_name'];
		$name     = time()."-".$_FILES['course_image']['name'];
		$path     = "../images/course/";
		move_uploaded_file($tmp_name,$path.$name);
		$course_image = $name;
		$query="INSERT INTO `course`(`category_id`,`course_name`, `course_name_ar`, `course_desc`,`course_level`, `course_desc_ar`, `course_hours`, `course_image`, `course_price`, `course_special_price`, `course_content`, `course_content_ar`,`start_date`,`end_date`) VALUES ($category_id,'$course_name','$course_name_ar','$course_desc','$course_desc_ar','$course_level',$course_hours,'$course_image',$course_price,$course_spe_price,'$course_content','$course_content_ar','$start_date','$end_date')";
		if (mysqli_query($con,$query)){
		
	echo "<div style='width:auto;margin:15px' class='alert alert-success role='alert'>Create Course Successfully </div>";
	
	/*echo "<script type='text/Javascript'>
			window.setTimeout(function() {
			window.location.href = 'courses.php';
			}, 2000);</script>";		
			
		*/
	} else {
		echo "Query Doesn't Excute";
			echo $query;
	}
	
	}
	else if($_FILES['course_image']['error'] == 4){
	echo "<div style='width:auto;margin:15px' class='alert alert-danger role='alert'>Please Select File </div>";

	echo "<script type='text/Javascript'>
			window.setTimeout(function() {
			window.location.href = 'courses.php';
			}, 2000);</script>";
	} else {
		exit();
	}
}
?>
<section class="forms">
	<div class="container-fluid">
		<div class="row">
			<!-- Basic Form-->
			<div class="col-lg-12">
				<div class="card">
					<div class="card-close">
						<div class="dropdown">
							<button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
							<div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a></div>
						</div>
					</div>
					<div class="card-header d-flex align-items-center">
						<h3 class="h4">Create Course
						</h3>
					</div>

					<div class="card-body">
						<form method="post" action="" enctype="multipart/form-data">
							<div class="form-group">
								<label class="form-control-label">Category Name</label>
								<?php $query="SELECT * FROM category";
								  $result = mysqli_query($con,$query);
									echo "<select name='category_id'>Category";
								  while($cat_data=mysqli_fetch_assoc($result)){
							      echo "<option value='".$cat_data['cat_id']."'>".$cat_data['cat_name']."</option>" ;
								}
								echo "</select>";

								?>
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Name</label>
								<input type="text" name="course_name" placeholder="ex : Full Stack Web" class="form-control">
							</div>
							<div class="form-group">
								<label class="form-control-label">Course Name Arabic</label>
								<input type="text" name="course_name_ar" placeholder="مثال : دورة تصميم مواقع الويب " class="form-control">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Description</label>
								<input type="text" name="course_desc" class="form-control" placeholder="In this course we will..">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Description Arabic</label>
								<input type="text" name="course_desc_ar" class="form-control" placeholder="...تحتوي هذه الدورة">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Level</label>
								<input type="text" name="course_level" class="form-control" placeholder="Beginner">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Hours</label>
								<input type="text" name="course_hours" class="form-control" placeholder="24">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Content </label><br>
								<textarea cols="55" rows="4" name="course_content" placeholder="1.Basic language.."></textarea>
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Content Arabic</label><br>
								<textarea cols="55" rows="4" name="course_content_ar" placeholder=".. PHP أساسيات لغة  "></textarea>
							</div>


							<div class="form-group">
								<label class="form-control-label">Course Price</label>
								<input type="text" name="course_price" class="form-control" placeholder="eg : 200$">
							</div>

							<div class="form-group">
								<label class="form-control-label">Course Special Price</label>
								<input type="text" name="course_spe_price" class="form-control" placeholder="eg : 100$">
							</div>

							<div class="form-group">
								<label class="form-control-label">Start Date</label>
								<input type="date" name="start_date" class="form-control">
							</div>

							<div class="form-group">
								<label class="form-control-label">End Date</label>
								<input type="date" name="end_date" class="form-control">
							</div>



							<div class="form-group">
								<label class="form-control-label">Course Image</label>
								<input type="file" name="course_image" class="form-control">
							</div>

							<div class="form-group">
								<input type="submit" name="submit" value="Create" class="btn btn-primary">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="form">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header d-flex align-items-center">
						<h3 class="h4">Courses Table</h3>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-striped table-sm">
								<thead>
									<tr>
										<th>Course ID</th>
										<th>Category Name</th>
										<th>Course Name</th>
										<th>Course Name Arabic</th>
										<th>Course Description</th>
										<th>Course Description Arabic</th>
										<th>Course Level</th>
										<th>Course Hours</th>
										<th>Course Price</th>
										<th>Course Special Price</th>
										<th>Course Image</th>
										<th>Course Content</th>
										<th>Course Content Arabic</th>
										<th>Start Date</th>
										<th>End Date</th>
										<th>Edit</th>
										<th>Delete</th>
									</tr>
								</thead>
								<?php
								
								$query       = "SELECT * FROM course";
 								$result      = mysqli_query($con,$query);
								while ($cour_data = mysqli_fetch_assoc($result)){
									$category_id = $cour_data['category_id'];
									$q           = "SELECT cat_name FROM category WHERE cat_id=$category_id";
									$res         = mysqli_query($con,$q);
									$cat_name    = mysqli_fetch_assoc($res);
									$cat_name    = $cat_name['cat_name'];
									echo "<tr>";
									echo "<th>".$cour_data['course_id']."</th>";
									echo "<th>".$cat_name  ."</th>";
									echo "<th>".$cour_data['course_name']."</th>";
									echo "<th>".$cour_data['course_name_ar']."</th>";
									echo "<th>".$cour_data['course_desc']."</th>";
									echo "<th>".$cour_data['course_desc_ar']."</th>";
									echo "<th>".$cour_data['course_level']."</th>";
									echo "<th>".$cour_data['course_hours']."H</th>";
									echo "<th>".$cour_data['course_price']."$</th>";
									echo "<th>".$cour_data['course_special_price']."$</th>";
									echo "<th><img src='../images/course/".$cour_data['course_image']."' height='50' width='50' class='rounded circle'></th>";
									echo "<th>".$cour_data['course_content']."</th>";
									echo "<th>".$cour_data['course_content_ar']."</th>";
									echo "<th>".date('Y-m-d',strtotime($cour_data['start_date']))."</th>";
									echo "<th>".date('Y-m-d',strtotime($cour_data['end_date']))."</th>";
									echo "<th><a href='update_course.php?course_id=".$cour_data['course_id']."'>Edit</a></th>";
									echo "<th><a href='delete_course.php?course_id=".$cour_data['course_id']."'>Delete</a></th>";
									echo "</tr>" ;	
								 }
							     ?>
								<tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include '../includes/footer.php';?>
